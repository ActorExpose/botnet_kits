#pragma once

#define HTTP_SERVER "192.227.223.183"
#define HTTP_PORT 80

#define TFTP_SERVER "192.227.223.183"
